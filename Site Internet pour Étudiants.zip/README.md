
  # Site Internet pour Étudiants

  This is a code bundle for Site Internet pour Étudiants. The original project is available at https://www.figma.com/design/nYFQMree3LCK0arUOCV2wt/Site-Internet-pour-%C3%89tudiants.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  